import type {
  // BookPersonGroupDetails,
  PersonRoleFilter,
  TagDetails,
  ThemeDto,
} from './references';

export interface ContentDto {
  id: number;
  title: string;
  description: string;
  countryId: number;
  countryName?: string | null;
  contentTypeId: number;
  contentType?: string | null;
  languageId: number;
  languageName?: string | null;
  yearFrom?: number | null;
  yearTo?: number | null;
  parentContentId?: number | null;
  position?: number | null;
  createdAt: string;
  updatedAt?: string | null;
  authors: string[];
  participants: PersonRoleFilter[];
  themes: ThemeDto[];
  booksCount: number;
  tags: TagDetails[];
}

export interface ContentListResponse {
  items: ContentDto[];
  nextCursor?: string | null;
  prevCursor?: string | null;
  totalCount: number;
  hasMore: boolean;
}

export interface ContentFilterRequest {
  searchQuery: string | null;
  lastId: number | null;
  limit: number | null;
}

export interface CreateContentRequest {
  title: string;
  description: string;
  countryId: number;
  contentTypeId: number;
  languageId: number;
  yearFrom?: number | null;
  yearTo?: number | null;
  parentContentId?: number | null;
  position?: number | null;
  personIds?: number[];
  themeIds?: number[];
}

export interface UpdateContentRequest {
  id: number;
  title: string;
  description: string;
  countryId: number;
  contentTypeId: number;
  languageId: number;
  yearFrom?: number | null;
  yearTo?: number | null;
  yearFromProvided: boolean;
  yearToProvided: boolean;
  parentContentId?: number | null;
  position?: number | null;
  personFilters?: PersonRoleFilter[];
  themeIds?: number[];
}
