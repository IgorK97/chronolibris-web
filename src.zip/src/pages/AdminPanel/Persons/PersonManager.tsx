/* eslint-disable @typescript-eslint/no-explicit-any */
import React, {
  useState,
  // useRef
} from 'react';
import {
  usePersons,
  useCreatePerson,
  useUpdatePerson,
  useDeletePerson,
} from '@/api/persons';
import type { CreatePersonRequest, UpdatePersonRequest } from '@/types';
import styles from './PersonManager.module.css';
import type { PersonDto } from '@/types';
import { AlertDialog } from '@/components/dialogs/AlertDialog';

export const PersonManager: React.FC = () => {
  const { data: persons, isLoading, error } = usePersons();
  const createMutation = useCreatePerson();
  const updateMutation = useUpdatePerson();
  const deleteMutation = useDeletePerson();
  const [deletingPersonId, setDeletingPersonId] = useState(0);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);

  const [formData, setFormData] = useState<CreatePersonRequest>({
    name: '',
    description: '',
  });

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<UpdatePersonRequest | null>(
    null
  );

  const handleCreate = async () => {
    if (!formData.name.trim()) {
      alert('Имя персоны обязательно');
      return;
    }

    if (!formData.description.trim()) {
      alert('Описание персоны обязательно');
      return;
    }

    try {
      await createMutation.mutateAsync(formData);
      setFormData({
        name: '',
        description: '',
      });
    } catch (err: any) {
      console.error('Ошибка создания персоны:', err);
      alert(err.response?.data?.message || 'Ошибка создания персоны');
    }
  };

  const handleUpdate = async (
    id: number,
    name: string,
    description: string
  ) => {
    if (!name.trim()) {
      alert('Имя персоны обязательно');
      return;
    }

    if (!description.trim()) {
      alert('Описание персоны обязательно');
      return;
    }

    try {
      await updateMutation.mutateAsync({
        id,
        data: {
          id,
          name,
          description,
        },
      });
      setEditingId(null);
      setEditFormData(null);
    } catch (err: any) {
      alert(err.response?.data?.message || 'Ошибка обновления персоны');
    }
  };

  const handleDelete = async () => {
    await deleteMutation.mutateAsync(deletingPersonId);
    setDeleteModalOpen(false);
  };

  const startEditing = (person: PersonDto) => {
    setEditingId(person.id);
    setEditFormData({
      id: person.id,
      name: person.name,
      description: person.description,
    });
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditFormData(null);
  };

  if (isLoading) {
    return (
      <div className={styles['person-manager']}>
        <div className={styles['loading']}>Загрузка...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles['person-manager']}>
        <div className={styles['error']}>
          Ошибка: {(error as Error).message}
        </div>
      </div>
    );
  }

  return (
    <div className={styles['person-manager']}>
      <h2>Управление персонами</h2>

      <div className={styles['form-section']}>
        <h3>Добавить новую персону</h3>
        <div className={styles['form-grid']}>
          <div className={styles['form-group']}>
            <label>Имя</label>
            <input
              type="text"
              placeholder="Имя персоны (например: Лев Толстой)"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              className={styles['input-field']}
              maxLength={255}
            />
          </div>

          <div className={styles['form-group']}>
            <label>Описание</label>
            <textarea
              placeholder="Краткое описание персоны"
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              className={styles['input-field textarea']}
              rows={3}
            />
          </div>

          <button
            onClick={handleCreate}
            disabled={
              createMutation.isPending ||
              !formData.name.trim() ||
              !formData.description.trim() ||
              formData.description.length < 20
            }
            className={styles['btn']}
          >
            {createMutation.isPending ? 'Создание...' : 'Создать персону'}
          </button>
        </div>
      </div>

      <div className={styles['list-section']}>
        <h3>Список персон ({persons?.length || 0})</h3>
        <table className={styles['persons-table']}>
          <thead>
            <tr>
              <th>Имя</th>
              <th>Описание</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {persons?.map((person) => (
              <tr key={person.id}>
                {editingId === person.id ? (
                  <>
                    <td>
                      <input
                        type="text"
                        value={editFormData?.name || ''}
                        onChange={(e) =>
                          setEditFormData({
                            ...editFormData!,
                            name: e.target.value,
                          })
                        }
                        className={styles['input-field']}
                        maxLength={256}
                      />
                    </td>
                    <td>
                      <textarea
                        value={editFormData?.description || ''}
                        onChange={(e) =>
                          setEditFormData({
                            ...editFormData!,
                            description: e.target.value,
                          })
                        }
                        className={styles['input-field textarea']}
                        rows={2}
                        maxLength={2000}
                        minLength={20}
                      />
                    </td>
                    <td>
                      <button
                        onClick={() =>
                          handleUpdate(
                            person.id,
                            editFormData?.name || '',
                            editFormData?.description || ''
                          )
                        }
                        className={`${styles['btn']} ${styles['btn-update']}`}
                        disabled={
                          updateMutation.isPending ||
                          !editFormData?.description ||
                          editFormData?.description.length < 20 ||
                          !editFormData.name.trim()
                        }
                      >
                        {updateMutation.isPending
                          ? 'Сохранение...'
                          : 'Сохранить'}
                      </button>
                      <button
                        onClick={cancelEditing}
                        className={`${styles['btn']} ${styles['btn-danger']}`}
                        disabled={updateMutation.isPending}
                      >
                        Отмена
                      </button>
                    </td>
                  </>
                ) : (
                  <>
                    <td className={styles['name-cell']}>{person.name}</td>
                    <td
                      className={styles['description-cell']}
                      title={person.description}
                    >
                      {person.description}
                    </td>
                    <td>
                      <button
                        onClick={() => startEditing(person)}
                        className={`${styles['btn']} ${styles['btn-update']}`}
                        disabled={
                          deleteMutation.isPending || updateMutation.isPending
                        }
                      >
                        Редактировать
                      </button>
                      <button
                        onClick={() => {
                          setDeletingPersonId(person.id);
                          setDeleteModalOpen(true);
                        }}
                        className={`${styles['btn']} ${styles['btn-danger']}`}
                        disabled={
                          deleteMutation.isPending || updateMutation.isPending
                        }
                      >
                        {deleteMutation.isPending ? 'Удаление...' : 'Удалить'}
                      </button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AlertDialog
        description={`Это действие нельзя будет отменить`}
        open={deleteModalOpen}
        title={`Вы действительно хотите удалить персоналию?`}
        handleAccept={() => {
          handleDelete();
        }}
        handleReject={() => {
          setDeleteModalOpen(false);
          setDeletingPersonId(0);
        }}
      />
    </div>
  );
};
