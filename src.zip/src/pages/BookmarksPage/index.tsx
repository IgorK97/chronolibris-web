import React, { useState } from 'react';
import { Bookmark, Search, BookOpen, Hash, FileType } from 'lucide-react';
import { useMyBookmarksPaged } from '@/api/bookmarks';
import styles from './BookmarksPage.module.css';
import { useDebounce } from '@/hooks';
import { BookFileStatuses } from '@/types';

const PAGE_SIZE = 20;

const getStatusBadge = (statusId: number) => {
  const statusMap: Record<number, { label: string; color: string }> = {
    [BookFileStatuses.PENDING]: { label: 'Ожидание', color: 'gray' },
    [BookFileStatuses.UPLOADED]: { label: 'Загружен', color: 'orange' },
    [BookFileStatuses.PROCESSING]: { label: 'Обработка', color: '#1a73e8' },
    [BookFileStatuses.COMPLETED]: { label: 'Готов', color: '#28a745' },
    [BookFileStatuses.FAILED]: { label: 'Ошибка', color: '#dc3545' },
    [BookFileStatuses.ARCHIVE]: { label: 'Архив', color: '#6F4F46' },
  };
  const status = statusMap[statusId] ?? null;
  return (
    status && (
      <span
        className={styles['status-badge']}
        style={{ backgroundColor: status.color }}
      >
        {status.label}
      </span>
    )
  );
};

export default function BookmarksPage() {
  const { setPendingXpointer } = useBookmarkNavigation();

  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const searchDeb = useDebounce(search, 200);
  const [inputValue, setInputValue] = useState('');
  const {
    data: result,
    error,
    isLoading,
  } = useMyBookmarksPaged(page, PAGE_SIZE, searchDeb);

  const totalPages = result ? Math.ceil(result.totalCount / PAGE_SIZE) : 0;

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });

  return (
    <div className={styles.layout}>
      <aside className={styles.sidebar}>
        <div className={styles['sidebar-icon']}>
          <Bookmark size={28} strokeWidth={1.6} />
        </div>
        <span className={styles['sidebar-label']}>Закладки</span>
      </aside>

      <main className={styles.main}>
        <div className={styles['search-wrapper']}>
          <Search size={16} className={styles['search-icon']} />
          <input
            className={styles['search-input']}
            type="text"
            placeholder="Поиск по названию или заметке…"
            value={inputValue}
            onChange={(e) => {
              setSearch(e.target.value);
            }}
          />
        </div>

        {result && !isLoading && (
          <p className={styles.counter}>
            {result.totalCount === 0
              ? 'Закладок не найдено'
              : `Найдено закладок: ${result.totalCount}`}
          </p>
        )}

        {isLoading && <p className={styles.info}>Загрузка…</p>}
        {error && <p className={styles.error}>{error.message}</p>}

        {!isLoading && result && result.items.length > 0 && (
          <ul className={styles.list}>
            {result.items.map((bm) => (
              <li key={bm.id}>
                <button
                  className={styles['bookmark-row']}
                  onClick={() => handleBookmarkClick(bm)}
                  title="Открыть в читалке"
                >
                  <span className={styles['row-icon']}>
                    <Bookmark size={18} strokeWidth={1.5} />
                  </span>

                  <span className={styles['row-body']}>
                    <span className={styles['row-title']}>
                      <BookOpen size={13} className={styles['inline-icon']} />
                      <span className={styles['book-title']}>
                        {bm.bookTitle}
                      </span>
                      <span className={styles['book-id']}>
                        <Hash size={11} />
                        {bm.bookId}
                      </span>
                    </span>

                    <span className={styles['row-file']}>
                      <FileType size={13} className={styles['inline-icon']} />
                      <span className={styles['file-format']}>
                        {bm.bookFileFormatName}
                      </span>
                      <span className={styles['file-id']}>
                        <Hash size={11} />
                        {bm.bookFileId}
                      </span>
                      {getStatusBadge(bm.bookFileStatusId)}
                    </span>

                    <span className={styles['row-context']}>{bm.context}</span>

                    {bm.note && (
                      <span className={styles['row-note']}>{bm.note}</span>
                    )}
                  </span>

                  <span className={styles['row-date']}>
                    {formatDate(bm.createdAt)}
                  </span>
                </button>
              </li>
            ))}
          </ul>
        )}

        {totalPages > 1 && (
          <div className={styles.pagination}>
            <button
              className={styles['page-btn']}
              disabled={page === 1}
              onClick={() => setPage((p) => p - 1)}
            >
              ‹
            </button>

            {Array.from({ length: totalPages }, (_, i) => i + 1)
              .filter(
                (p) => p === 1 || p === totalPages || Math.abs(p - page) <= 2
              )
              .reduce<(number | '…')[]>((acc, p, idx, arr) => {
                if (idx > 0 && p - (arr[idx - 1] as number) > 1) acc.push('…');
                acc.push(p);
                return acc;
              }, [])
              .map((item, idx) =>
                item === '…' ? (
                  <span
                    key={`ellipsis-${idx}`}
                    className={styles['page-ellipsis']}
                  >
                    …
                  </span>
                ) : (
                  <button
                    key={item}
                    className={`${styles['page-btn']} ${item === page ? styles['page-btn--active'] : ''}`}
                    onClick={() => setPage(item as number)}
                  >
                    {item}
                  </button>
                )
              )}

            <button
              className={styles['page-btn']}
              disabled={page === totalPages}
              onClick={() => setPage((p) => p + 1)}
            >
              ›
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
