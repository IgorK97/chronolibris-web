import React from 'react';
import { Bookmark } from 'lucide-react';
import styles from './index.module.css';

interface Props {
  /** Маршрут страницы закладок (по умолчанию /bookmarks) */
  href?: string;
  /** Tooltip */
  title?: string;
}

export default function BookmarksHeaderButton({
  href = '/bookmarks',
  title = 'Мои закладки',
}: Props) {
  const router = useRouter();
  const pathname = usePathname();

  const isActive = pathname === href || pathname.startsWith(href + '/');

  const handleClick = () => {
    router.push(href);
  };

  return (
    <button
      className={`${styles.btn} ${isActive ? styles['btn--active'] : ''}`}
      onClick={handleClick}
      title={title}
      aria-label={title}
      aria-current={isActive ? 'page' : undefined}
    >
      <Bookmark
        size={20}
        strokeWidth={1.7}
        /* Заполняем иконку если мы на странице закладок */
        fill={isActive ? 'currentColor' : 'none'}
      />
    </button>
  );
}